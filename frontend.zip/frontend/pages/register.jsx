import { useState } from "react";
import "./register.css";

function Register() {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [passwordError, setPasswordError] = useState("");
  const [message, setMessage] = useState("");

  const handleConfirmPassword = (value) => {
    setConfirmPassword(value);
    setMessage("");

    if (value !== password) {
      setPasswordError("Passwords do not match.");
    } else {
      setPasswordError("");
    }
  };

  const handleRegister = () => {
    setMessage("");

    if (!password) {
      setPasswordError("Please enter a password.");
      return;
    }

    if (!confirmPassword) {
      setPasswordError("Please confirm your password.");
      return;
    }

    if (password !== confirmPassword) {
      setPasswordError("Passwords do not match.");
      return;
    }

    setPasswordError("");

    setMessage(
      "Registration details received. Authentication will be connected to the backend."
    );
  };

  return (
    <div className="register-page">

      <div className="register-card">

        {/* Header */}
        <div className="register-header">
          <h1>CareerCompass</h1>
          <p>Your Career. Your Future.</p>
        </div>

        {/* Form */}
        <div className="register-form">

          <h2>Create Your Account</h2>

          <p className="register-subtitle">
            Start your personalized career journey with CareerCompass.
          </p>

          {/* Full Name */}
          <div className="form-group">
            <label htmlFor="fullName">Full Name</label>

            <input
              id="fullName"
              type="text"
              placeholder="Enter your full name"
            />
          </div>

          {/* Email */}
          <div className="form-group">
            <label htmlFor="email">Email</label>

            <input
              id="email"
              type="email"
              placeholder="Enter your email"
            />
          </div>

          {/* Password */}
          <div className="form-group">
            <label htmlFor="password">Password</label>

            <div className="password-wrapper">

              <input
                id="password"
                type={showPassword ? "text" : "password"}
                placeholder="Create a password"
                value={password}
                onChange={(e) => {
                  const value = e.target.value;

                  setPassword(value);
                  setMessage("");

                  if (
                    confirmPassword &&
                    value !== confirmPassword
                  ) {
                    setPasswordError("Passwords do not match.");
                  } else {
                    setPasswordError("");
                  }
                }}
              />

              <button
                type="button"
                className="password-toggle"
                onClick={() =>
                  setShowPassword(!showPassword)
                }
              >
                {showPassword ? "Hide" : "Show"}
              </button>

            </div>
          </div>

          {/* Confirm Password */}
          <div className="form-group">
            <label htmlFor="confirmPassword">
              Confirm Password
            </label>

            <div className="password-wrapper">

              <input
                id="confirmPassword"
                type={
                  showConfirmPassword
                    ? "text"
                    : "password"
                }
                placeholder="Re-enter your password"
                value={confirmPassword}
                onChange={(e) =>
                  handleConfirmPassword(e.target.value)
                }
              />

              <button
                type="button"
                className="password-toggle"
                onClick={() =>
                  setShowConfirmPassword(
                    !showConfirmPassword
                  )
                }
              >
                {showConfirmPassword
                  ? "Hide"
                  : "Show"}
              </button>

            </div>

            {passwordError && (
              <p className="password-error">
                {passwordError}
              </p>
            )}

            {confirmPassword &&
              password === confirmPassword && (
                <p className="password-success">
                  ✓ Passwords match
                </p>
              )}

          </div>

          {/* Terms */}
          <div className="terms-container">

            <input
              type="checkbox"
              id="terms"
            />

            <label htmlFor="terms">
              I agree to the Terms & Conditions and
              Privacy Policy.
            </label>

          </div>

          {/* Register Button */}
          <button
            type="button"
            className="register-button"
            onClick={handleRegister}
          >
            Create Account
          </button>

          {message && (
            <p className="register-success">
              {message}
            </p>
          )}

          {/* Login */}
          <p className="login-text">
            Already have an account?{" "}
            <a href="/">
              Login
            </a>
          </p>

        </div>

      </div>

    </div>
  );
}

export default Register;